//CallCenter.� ����������� �������� ��������� ����������.�������� ����� ����������� ������ ������ �������, ��������� ������ ����� �����
//�������.

#include "pch.h"
#include <gtest/gtest.h>
#include <iostream>
#include <vector>
#include <queue>
#include <chrono>
#include <thread>
#include <random>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <mutex>
#include <condition_variable>

using namespace std;
auto logger = spdlog::stdout_color_mt("logger");

// Structure representing a client
struct Client {
    int id;
    chrono::time_point<chrono::system_clock> callTime;
};

// Class representing an operator
class Operator {
public:
    bool isBusy = false;
    mutex mtx;
    condition_variable cv;

    void serveClient(Client client, int operatorId) {
        unique_lock<mutex> lock(mtx);
        isBusy = true;
        auto start_time = chrono::system_clock::now();
        logger->info("Operator {} starts serving client {} at time {}", operatorId, client.id, chrono::system_clock::to_time_t(start_time));

        // Simulate serving the client (random time)
        random_device rd;
        mt19937 gen(rd());
        uniform_int_distribution<> distrib(2, 5); // Service time from 2 to 5 seconds
        this_thread::sleep_for(chrono::seconds(distrib(gen)));

        auto end_time = chrono::system_clock::now();
        logger->info("Operator {} finishes serving client {} at time {}", operatorId, client.id, chrono::system_clock::to_time_t(end_time));
        isBusy = false;
        cv.notify_one(); // Notify that serving is complete
    }

    // Method to wait for completion
    void waitForCompletion() {
        unique_lock<mutex> lock(mtx);
        cv.wait(lock, [this] { return !isBusy; });
    }
};

queue<Client> generateClients(int numClients) {
    queue<Client> clientQueue;
    for (int i = 1; i <= numClients; ++i) {
        clientQueue.push({ i, chrono::system_clock::now() });
    }
    return clientQueue;
}

// Tests
TEST(CallCenterTest, ConcurrentClientsMultipleOperators) {
    int numOperators = 3;
    vector<Operator> operators(numOperators);
    queue<Client> clientQueue = generateClients(10);
    atomic<int> clientsServed(0); // Use atomic for thread safety

    vector<thread> threads;
    for (int i = 0; i < numOperators; ++i) {
        threads.push_back(thread([&operators, &clientQueue, i, &clientsServed]() {
            while (true) {
                unique_lock<mutex> lock(operators[i].mtx);
                operators[i].cv.wait(lock, [&clientQueue, &operators, i] {
                    return !clientQueue.empty() && !operators[i].isBusy;
                    });

                if (clientQueue.empty()) {
                    return; // Exit thread if queue is empty
                }

                Client client = clientQueue.front();
                clientQueue.pop();
                lock.unlock(); // Release lock before serving

                operators[i].serveClient(client, i); // Pass operator ID to serveClient
                clientsServed++;
            }
            }));
    }

    for (auto& t : threads) {
        t.join();
    }

    ASSERT_EQ(clientsServed, 10); // Check if all clients were served
    ASSERT_TRUE(clientQueue.empty());
}

int main(int argc, char** argv) {
    spdlog::set_level(spdlog::level::info);
    spdlog::set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%^%l%$] %v");
    auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}